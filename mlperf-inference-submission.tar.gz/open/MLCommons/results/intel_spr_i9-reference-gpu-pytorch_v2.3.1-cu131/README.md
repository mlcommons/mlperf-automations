| Model   | Scenario   |   Accuracy |   Throughput | Latency (in ms)   |
|---------|------------|------------|--------------|-------------------|
| yolo-95 | offline    |     53.108 |       12.298 | -                 |